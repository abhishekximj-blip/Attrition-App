
import pandas as pd
import pickle
import numpy as np
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix

# Load the final model
gb_model = pickle.load(open('gradient_boosting_model_final.pkl', 'rb'))
df = pd.read_csv('hr_attrition_final_21features.csv')

# Get test set
from sklearn.model_selection import train_test_split
X = df.drop('Attrition', axis=1)
y = df['Attrition']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=42, stratify=y)

# Make predictions
pred_proba = gb_model.predict_proba(X_test)[:, 1]

def categorize_risk(probability):
    if probability >= 0.70:
        return 'RED'
    elif probability >= 0.40:
        return 'ORANGE'
    else:
        return 'GREEN'

# Create comprehensive prediction report
predictions = pd.DataFrame({
    'Employee_ID': range(1, len(X_test) + 1),
    'Age': X_test['Age'].values.astype(int),
    'JobLevel': X_test['JobLevel'].values.astype(int),
    'YearsAtCompany': X_test['YearsAtCompany'].values.round(1),
    'JobSatisfaction': X_test['JobSatisfaction'].values.astype(int),
    'WorkLifeBalance': X_test['WorkLifeBalance'].values.astype(int),
    'RelationshipSatisfaction': X_test['RelationshipSatisfaction'].values.astype(int),
    'YearsSinceLastPromotion': X_test['YearsSinceLastPromotion'].values.round(1),
    'DailyWorkingHours': X_test['DailyWorkingHours'].values.round(1),
    'Attrition_Probability': pred_proba,
    'Risk_Category': [categorize_risk(p) for p in pred_proba],
    'Actual_Attrition': y_test.values
})

print("=" * 140)
print("EMPLOYEE ATTRITION RISK PREDICTION - SAMPLE RESULTS (20 EMPLOYEES)")
print("=" * 140)
print("\nEmpID  Age  JobLvl  Tenure  JobSat  WLB  RelSat  YrsSinceProm  DailyHrs  RiskProb   Category  ActualAttrition")
print("-" * 140)

for idx, row in predictions.head(20).iterrows():
    actual = 'YES' if predictions.iloc[idx]['Actual_Attrition'] == 1 else 'NO'
    print(f"{row['Employee_ID']:5d}  {row['Age']:3d}   {row['JobLevel']:1d}      {row['YearsAtCompany']:5.1f}   {row['JobSatisfaction']:1d}      {row['WorkLifeBalance']:1d}     {row['RelationshipSatisfaction']:1d}       {row['YearsSinceLastPromotion']:5.1f}        {row['DailyWorkingHours']:5.1f}     {row['Attrition_Probability']*100:6.1f}%    {row['Risk_Category']:6s}      {actual}")

print("\n" + "=" * 140)
print("RISK CATEGORY BREAKDOWN")
print("=" * 140)

risk_counts = predictions['Risk_Category'].value_counts()
total = len(predictions)

print(f"\n🔴 RED (High Risk, >70% probability):      {risk_counts.get('RED', 0):4d} employees ({risk_counts.get('RED', 0)/total*100:5.1f}%)")
print(f"🟠 ORANGE (Medium Risk, 40-70% prob):    {risk_counts.get('ORANGE', 0):4d} employees ({risk_counts.get('ORANGE', 0)/total*100:5.1f}%)")
print(f"🟢 GREEN (Low Risk, <40% probability):   {risk_counts.get('GREEN', 0):4d} employees ({risk_counts.get('GREEN', 0)/total*100:5.1f}%)")

# Show sample RED risk employees with recommendations
print("\n" + "=" * 140)
print("DETAILED ANALYSIS - RED RISK EMPLOYEES (IMMEDIATE ACTION REQUIRED)")
print("=" * 140)

red_employees = predictions[predictions['Risk_Category'] == 'RED'].head(5)

for idx_outer, (i, emp) in enumerate(red_employees.iterrows(), 1):
    print(f"\n{idx_outer}. EMPLOYEE #{int(emp['Employee_ID'])} (Risk: {emp['Attrition_Probability']*100:.1f}%)")
    print("-" * 100)
    print(f"   Age: {int(emp['Age'])}  |  Job Level: {int(emp['JobLevel'])}  |  Tenure: {emp['YearsAtCompany']:.1f} years  |  Daily Hours: {emp['DailyWorkingHours']:.1f}")
    
    # Risk factors
    risk_factors = []
    if emp['JobSatisfaction'] <= 2:
        risk_factors.append("LOW Job Satisfaction")
    if emp['WorkLifeBalance'] <= 2:
        risk_factors.append("POOR Work-Life Balance")
    if emp['RelationshipSatisfaction'] <= 2:
        risk_factors.append("WEAK Team Relationships")
    if emp['YearsSinceLastPromotion'] > 3:
        risk_factors.append(f"NO promotion in {emp['YearsSinceLastPromotion']:.1f} years")
    if emp['DailyWorkingHours'] > 9:
        risk_factors.append(f"EXCESSIVE hours ({emp['DailyWorkingHours']:.1f}/day)")
    
    print(f"\n   ⚠️  PRIMARY RISK FACTORS:")
    for factor in risk_factors:
        print(f"       • {factor}")
    
    print(f"\n   ✓ RECOMMENDED ACTIONS:")
    if emp['YearsSinceLastPromotion'] > 3:
        print(f"       → Schedule promotion discussion (last one: {emp['YearsSinceLastPromotion']:.1f} years ago)")
    if emp['JobSatisfaction'] <= 2:
        print(f"       → Conduct engagement survey or 1-on-1 with manager (satisfaction: {int(emp['JobSatisfaction'])}/4)")
    if emp['WorkLifeBalance'] <= 2:
        print(f"       → Review workload and daily hours (currently: {emp['DailyWorkingHours']:.1f} hrs/day)")
    if emp['RelationshipSatisfaction'] <= 2:
        print(f"       → Facilitate team building or change of team/reporting manager")
    print(f"       → Offer career development or skill enhancement opportunities")
    print(f"       → Schedule manager check-in within 7 days")

# Summary statistics
print("\n" + "=" * 140)
print("MODEL ACCURACY & RELIABILITY")
print("=" * 140)

y_pred = gb_model.predict(X_test)
y_pred_proba = gb_model.predict_proba(X_test)[:, 1]

accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)
auc = roc_auc_score(y_test, y_pred_proba)
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()

print(f"\nAccuracy:              {accuracy*100:6.2f}%  (Overall correctness)")
print(f"Precision:             {precision*100:6.2f}%  (Of predicted at-risk, how many actually leave)")
print(f"Recall:                {recall*100:6.2f}%  (Of actual leavers, how many we catch)")
print(f"F1-Score:              {f1:6.4f}   (Balance of precision & recall)")
print(f"ROC-AUC:               {auc:6.4f}   (Discrimination ability)")

print(f"\nConfusion Matrix:")
print(f"  True Negatives (TN):  {tn:4d}  (Correctly predicted stayers)")
print(f"  True Positives (TP):  {tp:4d}  (Correctly predicted leavers)")
print(f"  False Positives (FP): {fp:4d}  (False alarms - predicted leave but stayed)")
print(f"  False Negatives (FN): {fn:4d}  (Missed cases - predicted stay but left)")

# Save comprehensive report
predictions.to_csv('comprehensive_attrition_report.csv', index=False)

print("\n" + "=" * 140)
print("✓ COMPREHENSIVE REPORT SAVED: comprehensive_attrition_report.csv")
print("=" * 140)
