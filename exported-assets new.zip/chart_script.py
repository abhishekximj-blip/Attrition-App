
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np

# Data
performance_metrics = {"Accuracy": 0.9000, "Precision": 0.9042, "Recall": 0.9869, "ROC_AUC": 0.9468}
risk_distribution = {"RED": 328, "ORANGE": 10, "GREEN": 22}
feature_importance = [
    {"Feature": "Years Since Promotion", "Importance": 12.66},
    {"Feature": "Daily Working Hours", "Importance": 9.90},
    {"Feature": "Relationship Satisfaction", "Importance": 8.68},
    {"Feature": "Job Satisfaction", "Importance": 8.39},
    {"Feature": "Distance From Home", "Importance": 8.28},
    {"Feature": "Work Life Balance", "Importance": 8.28},
    {"Feature": "Num Companies Worked", "Importance": 5.30},
    {"Feature": "Over Time", "Importance": 5.00},
    {"Feature": "Job Level", "Importance": 4.65},
    {"Feature": "Monthly Income", "Importance": 4.47}
]
confusion_matrix = {"True_Positive": 302, "False_Positive": 32, "False_Negative": 4, "True_Negative": 22}

# Create subplots with custom layout
fig = make_subplots(
    rows=4, cols=4,
    row_heights=[0.15, 0.35, 0.35, 0.15],
    column_widths=[0.25, 0.25, 0.25, 0.25],
    specs=[
        [{"type": "indicator"}, {"type": "indicator"}, {"type": "indicator"}, {"type": "indicator"}],
        [{"type": "pie", "colspan": 2}, None, {"type": "bar", "colspan": 2}, None],
        [{"type": "pie", "colspan": 2}, None, {"type": "bar", "colspan": 2}, None],
        [{"type": "table", "colspan": 4}, None, None, None]
    ],
    subplot_titles=("", "", "", "", "Risk Category Distribution", "", "Top 10 Feature Importance", "", "", "", "Confusion Matrix"),
    vertical_spacing=0.12,
    horizontal_spacing=0.08
)

# 1. Performance Metrics (Top Row)
metrics = [
    ("Accuracy", 90.00, 1, 1),
    ("Precision", 90.42, 1, 2),
    ("Recall", 98.69, 1, 3),
    ("ROC-AUC", 94.68, 1, 4)
]

for metric_name, metric_value, row, col in metrics:
    fig.add_trace(
        go.Indicator(
            mode="number",
            value=metric_value,
            title={"text": metric_name, "font": {"size": 16, "color": "#2C3E50"}},
            number={"suffix": "%", "font": {"size": 32, "color": "#1FB8CD"}},
            domain={'x': [0, 1], 'y': [0, 1]}
        ),
        row=row, col=col
    )

# 2. Risk Category Distribution (Middle-Left as Pie)
risk_labels = list(risk_distribution.keys())
risk_values = list(risk_distribution.values())
risk_colors = ["#E74C3C", "#F39C12", "#27AE60"]

fig.add_trace(
    go.Pie(
        labels=risk_labels,
        values=risk_values,
        marker=dict(colors=risk_colors),
        text=[f"{v} ({v/sum(risk_values)*100:.1f}%)" for v in risk_values],
        textinfo='label+text',
        textposition='inside',
        hovertemplate='<b>%{label}</b><br>Count: %{value}<br>Percentage: %{percent}<extra></extra>'
    ),
    row=2, col=1
)

# 3. Feature Importance (Middle-Right as Horizontal Bar)
df = pd.DataFrame(feature_importance)

# Abbreviate feature names to fit 15 char limit
abbrev_features = []
for feat in df['Feature']:
    if len(feat) <= 15:
        abbrev_features.append(feat)
    else:
        # Abbreviate long names
        if feat == "Years Since Promotion":
            abbrev_features.append("Yrs Since Promo")
        elif feat == "Daily Working Hours":
            abbrev_features.append("Daily Work Hrs")
        elif feat == "Relationship Satisfaction":
            abbrev_features.append("Relation Satisf")
        elif feat == "Job Satisfaction":
            abbrev_features.append("Job Satisf")
        elif feat == "Distance From Home":
            abbrev_features.append("Dist From Home")
        elif feat == "Work Life Balance":
            abbrev_features.append("Work-Life Bal")
        elif feat == "Num Companies Worked":
            abbrev_features.append("Num Co Worked")
        else:
            abbrev_features.append(feat[:15])

fig.add_trace(
    go.Bar(
        y=abbrev_features[::-1],
        x=df['Importance'][::-1],
        orientation='h',
        marker=dict(color='#1FB8CD'),
        text=[f"{val:.1f}%" for val in df['Importance'][::-1]],
        textposition='outside',
        hovertemplate='<b>%{y}</b><br>Importance: %{x:.2f}%<extra></extra>'
    ),
    row=2, col=3
)

# 4. Confusion Matrix (Bottom as Table)
cm_data = [
    ["", "<b>Predicted: Stay</b>", "<b>Predicted: Leave</b>"],
    ["<b>Actual: Stay</b>", f"TN: {confusion_matrix['True_Negative']}", f"FP: {confusion_matrix['False_Positive']}"],
    ["<b>Actual: Leave</b>", f"FN: {confusion_matrix['False_Negative']}", f"TP: {confusion_matrix['True_Positive']}"]
]

fig.add_trace(
    go.Table(
        header=dict(
            values=cm_data[0],
            fill_color='#34495E',
            font=dict(color='white', size=14),
            align='center',
            height=35
        ),
        cells=dict(
            values=list(zip(*cm_data[1:])),
            fill_color=[['#ECF0F1', '#ECF0F1'], ['#D5DBDB', '#D5DBDB'], ['#BDC3C7', '#BDC3C7']],
            font=dict(color='#2C3E50', size=13),
            align='center',
            height=30
        )
    ),
    row=4, col=1
)

# Update layout
fig.update_layout(
    title={
        "text": "Employee Attrition Prediction Model Dashboard (2023)<br><span style='font-size: 18px; font-weight: normal;'>High-risk employees dominate attrition predictions</span>",
        "x": 0.5,
        "xanchor": "center"
    },
    showlegend=False,
    paper_bgcolor='white',
    plot_bgcolor='white'
)

# Update axes for feature importance chart
fig.update_xaxes(title_text="Importance (%)", row=2, col=3, gridcolor='#E8E8E8')
fig.update_yaxes(title_text="", row=2, col=3)

# Make pie chart uniform text
fig.update_layout(uniformtext_minsize=14, uniformtext_mode='hide')

# Save
fig.write_image("attrition_dashboard.png", width=1400, height=1200)
fig.write_image("attrition_dashboard.svg", format="svg", width=1400, height=1200)
