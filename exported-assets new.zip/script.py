
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, classification_report

# Load the original data
df = pd.read_csv('hr_attrition_expanded.csv')

# Remove StockOptionLevel from features
df_updated = df.drop('StockOptionLevel', axis=1)

print("=" * 90)
print("ATTRITION MODEL - STOCK OPTION REMOVED (21 FEATURES)")
print("=" * 90)

print("\nFeatures Used (21):")
features_list = [col for col in df_updated.columns if col != 'Attrition']
for i, feat in enumerate(features_list, 1):
    print(f"  {i:2d}. {feat}")

# Separate features and target
X = df_updated.drop('Attrition', axis=1)
y = df_updated['Attrition']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=42, stratify=y)

print(f"\nTraining Set: {X_train.shape[0]} samples")
print(f"Test Set: {X_test.shape[0]} samples")

# ============================================================================
# GRADIENT BOOSTING MODEL (BEST PERFORMER)
# ============================================================================
print("\n" + "-" * 90)
print("GRADIENT BOOSTING MODEL (WITHOUT STOCK OPTION)")
print("-" * 90)

gb_model = GradientBoostingClassifier(
    n_estimators=150,
    learning_rate=0.05,
    max_depth=7,
    min_samples_split=10,
    min_samples_leaf=5,
    subsample=0.8,
    random_state=42
)

gb_model.fit(X_train, y_train)
gb_pred = gb_model.predict(X_test)
gb_pred_proba = gb_model.predict_proba(X_test)[:, 1]

gb_accuracy = accuracy_score(y_test, gb_pred)
gb_precision = precision_score(y_test, gb_pred)
gb_recall = recall_score(y_test, gb_pred)
gb_f1 = f1_score(y_test, gb_pred)
gb_auc = roc_auc_score(y_test, gb_pred_proba)

print(f"\nAccuracy:  {gb_accuracy:.4f} ({gb_accuracy*100:.2f}%)")
print(f"Precision: {gb_precision:.4f}")
print(f"Recall:    {gb_recall:.4f}")
print(f"F1-Score:  {gb_f1:.4f}")
print(f"ROC-AUC:   {gb_auc:.4f}")

# Cross-validation
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = cross_val_score(gb_model, X_train, y_train, cv=skf, scoring='accuracy')
print(f"5-Fold CV Accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")

# ============================================================================
# FEATURE IMPORTANCE - UPDATED
# ============================================================================
print("\n" + "=" * 90)
print("UPDATED FEATURE IMPORTANCE (21 FEATURES)")
print("=" * 90)

feature_importance = pd.DataFrame({
    'Feature': X.columns,
    'Importance': gb_model.feature_importances_
}).sort_values('Importance', ascending=False).reset_index(drop=True)

feature_importance['Importance_Percentage'] = (feature_importance['Importance'] * 100).round(2)
feature_importance['Cumulative_Importance'] = feature_importance['Importance_Percentage'].cumsum().round(2)

print("\nTop 15 Features:")
top_15 = feature_importance.head(15)
for idx, row in top_15.iterrows():
    bar_length = int(row['Importance_Percentage'] / 2)
    bar = "█" * bar_length
    print(f"{idx+1:2d}. {row['Feature']:30s} {bar} {row['Importance_Percentage']:6.2f}%")

# ============================================================================
# RISK CATEGORIZATION
# ============================================================================
print("\n" + "=" * 90)
print("RISK PREDICTIONS - SAMPLE (15 EMPLOYEES)")
print("=" * 90)

def categorize_risk(probability):
    if probability >= 0.70:
        return 'RED - HIGH RISK'
    elif probability >= 0.40:
        return 'ORANGE - MEDIUM RISK'
    else:
        return 'GREEN - LOW RISK'

risk_df = pd.DataFrame({
    'Employee_ID': range(1, len(X_test) + 1),
    'Attrition_Probability': gb_pred_proba,
    'Risk_Category': [categorize_risk(p) for p in gb_pred_proba],
    'Actual_Attrition': y_test.values
})

sample_output = risk_df.head(15).copy()
sample_output['Attrition_Probability'] = sample_output['Attrition_Probability'].apply(lambda x: f"{x:.2%}")
sample_output['Actual_Attrition'] = sample_output['Actual_Attrition'].apply(lambda x: 'Yes' if x == 1 else 'No')
print("\n" + sample_output.to_string(index=False))

# Risk summary
print("\n" + "-" * 90)
print("RISK DISTRIBUTION SUMMARY")
print("-" * 90)
risk_summary = risk_df.groupby('Risk_Category').agg({
    'Attrition_Probability': ['min', 'max', 'mean', 'count'],
    'Actual_Attrition': 'sum'
}).round(4)

print(f"\nGREEN (Low Risk, <40% probability):     {len(risk_df[risk_df['Risk_Category'] == 'GREEN - LOW RISK']):3d} employees")
print(f"ORANGE (Medium Risk, 40-70% probability): {len(risk_df[risk_df['Risk_Category'] == 'ORANGE - MEDIUM RISK']):3d} employees")
print(f"RED (High Risk, >70% probability):       {len(risk_df[risk_df['Risk_Category'] == 'RED - HIGH RISK']):3d} employees")

# Save updated files
import pickle
pickle.dump(gb_model, open('gradient_boosting_model_updated.pkl', 'wb'))
risk_df.to_csv('employee_attrition_predictions_updated.csv', index=False)
feature_importance.to_csv('feature_importance_updated.csv', index=False)

print("\n" + "=" * 90)
print("✓ MODEL UPDATED AND SAVED (Stock Option Removed)")
print("=" * 90)
print("\nPerformance Comparison:")
print(f"  Previous Model (22 features): 90.56% Accuracy")
print(f"  Updated Model (21 features):  {gb_accuracy*100:.2f}% Accuracy")
print(f"  Impact: {(gb_accuracy*100 - 90.56):.2f}% change (Stock Option was not critical)")
