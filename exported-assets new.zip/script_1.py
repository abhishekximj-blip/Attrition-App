
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

np.random.seed(42)

# Recreate dataset WITHOUT StockOptionLevel (21 features only)
n_samples = 1200

data = {
    # Core Minimal Features
    'YearsAtCompany': np.random.uniform(0.5, 30, n_samples),
    'JobLevel': np.random.choice([1, 2, 3, 4, 5], n_samples, p=[0.3, 0.3, 0.2, 0.1, 0.1]),
    'OverTime': np.random.choice([0, 1], n_samples, p=[0.7, 0.3]),
    'JobSatisfaction': np.random.choice([1, 2, 3, 4], n_samples),
    'WorkLifeBalance': np.random.choice([1, 2, 3, 4], n_samples),
    'PerformanceRating': np.random.choice([1, 2, 3, 4], n_samples),
    
    # Demographic Features
    'Age': np.random.uniform(18, 65, n_samples),
    'MaritalStatus': np.random.choice([0, 1, 2], n_samples, p=[0.3, 0.6, 0.1]),
    'EducationField': np.random.choice([0, 1, 2, 3], n_samples, p=[0.2, 0.6, 0.15, 0.05]),
    
    # Career Progression Features
    'YearsSinceLastPromotion': np.random.uniform(0, 15, n_samples),
    'NumCompaniesWorked': np.random.choice([1, 2, 3, 4, 5, 6], n_samples),
    'YearsWithCurrentManager': np.random.uniform(0, 20, n_samples),
    'TrainingTimesLastYear': np.random.choice([0, 1, 2, 3, 4, 5, 6], n_samples),
    
    # Compensation & Perks (NO StockOptionLevel)
    'MonthlyIncome': np.random.uniform(20000, 200000, n_samples),
    'PercentSalaryHike': np.random.uniform(0, 25, n_samples),
    
    # Work Environment
    'DistanceFromHome': np.random.uniform(1, 50, n_samples),
    'BusinessTravel': np.random.choice([0, 1, 2], n_samples, p=[0.5, 0.3, 0.2]),
    'DailyWorkingHours': np.random.uniform(7, 12, n_samples),
    
    # Engagement & Attendance
    'RelationshipSatisfaction': np.random.choice([1, 2, 3, 4], n_samples),  # EXPLAINED BELOW
    'NumProjects': np.random.choice([1, 2, 3, 4, 5, 6, 7], n_samples),
    'AttendancePercentage': np.random.uniform(80, 100, n_samples),
}

df = pd.DataFrame(data)

# Create target variable
def calculate_attrition(row):
    risk_score = 0
    if row['YearsAtCompany'] < 2: risk_score += 0.25
    if row['JobSatisfaction'] <= 2: risk_score += 0.20
    if row['WorkLifeBalance'] <= 2: risk_score += 0.18
    if row['YearsSinceLastPromotion'] > 3: risk_score += 0.18
    if row['MonthlyIncome'] < 40000: risk_score += 0.12
    if row['OverTime'] == 1: risk_score += 0.12
    if row['DistanceFromHome'] > 30: risk_score += 0.10
    if row['DailyWorkingHours'] > 9: risk_score += 0.10
    if row['PercentSalaryHike'] < 5: risk_score += 0.08
    if row['NumCompaniesWorked'] > 4: risk_score += 0.10
    if row['TrainingTimesLastYear'] == 0: risk_score += 0.08
    if row['Age'] < 25 and row['JobLevel'] <= 2: risk_score += 0.10
    if row['RelationshipSatisfaction'] <= 2: risk_score += 0.10
    if row['PerformanceRating'] >= 3: risk_score -= 0.08
    if row['JobLevel'] >= 4: risk_score -= 0.10
    if row['RelationshipSatisfaction'] >= 3: risk_score -= 0.08
    if row['AttendancePercentage'] > 95: risk_score -= 0.05
    if row['TrainingTimesLastYear'] >= 3: risk_score -= 0.08
    return 1 if risk_score > 0.20 else 0

df['Attrition'] = df.apply(calculate_attrition, axis=1)

print("=" * 90)
print("ATTRITION MODEL - UPDATED (21 FEATURES, STOCK OPTION REMOVED)")
print("=" * 90)
print(f"\nDataset Shape: {df.shape}")
print(f"Attrition Rate: {df['Attrition'].mean()*100:.2f}%")

print("\n21 FEATURES USED:")
features_list = [col for col in df.columns if col != 'Attrition']
for i, feat in enumerate(features_list, 1):
    print(f"  {i:2d}. {feat}")

# Separate features and target
X = df.drop('Attrition', axis=1)
y = df['Attrition']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=42, stratify=y)

# Train Gradient Boosting Model
gb_model = GradientBoostingClassifier(
    n_estimators=150,
    learning_rate=0.05,
    max_depth=7,
    min_samples_split=10,
    min_samples_leaf=5,
    subsample=0.8,
    random_state=42
)

gb_model.fit(X_train, y_train)
gb_pred = gb_model.predict(X_test)
gb_pred_proba = gb_model.predict_proba(X_test)[:, 1]

gb_accuracy = accuracy_score(y_test, gb_pred)
gb_precision = precision_score(y_test, gb_pred)
gb_recall = recall_score(y_test, gb_pred)
gb_f1 = f1_score(y_test, gb_pred)
gb_auc = roc_auc_score(y_test, gb_pred_proba)

print("\n" + "=" * 90)
print("MODEL PERFORMANCE (GRADIENT BOOSTING - 21 FEATURES)")
print("=" * 90)
print(f"\nAccuracy:  {gb_accuracy:.4f} ({gb_accuracy*100:.2f}%)")
print(f"Precision: {gb_precision:.4f}")
print(f"Recall:    {gb_recall:.4f}")
print(f"F1-Score:  {gb_f1:.4f}")
print(f"ROC-AUC:   {gb_auc:.4f}")

skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = cross_val_score(gb_model, X_train, y_train, cv=skf, scoring='accuracy')
print(f"5-Fold CV Accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")

# Feature importance
feature_importance = pd.DataFrame({
    'Feature': X.columns,
    'Importance': gb_model.feature_importances_
}).sort_values('Importance', ascending=False).reset_index(drop=True)

feature_importance['Importance_Percentage'] = (feature_importance['Importance'] * 100).round(2)

print("\n" + "=" * 90)
print("TOP 15 IMPORTANT FEATURES")
print("=" * 90)
top_15 = feature_importance.head(15)
for idx, row in top_15.iterrows():
    bar_length = int(row['Importance_Percentage'] / 2)
    bar = "█" * bar_length
    print(f"{idx+1:2d}. {row['Feature']:30s} {bar} {row['Importance_Percentage']:6.2f}%")

# Save files
import pickle
pickle.dump(gb_model, open('gradient_boosting_model_final.pkl', 'wb'))
df.to_csv('hr_attrition_final_21features.csv', index=False)
feature_importance.to_csv('feature_importance_final.csv', index=False)

print("\n" + "=" * 90)
print("✓ FILES SAVED SUCCESSFULLY")
print("=" * 90)
print("Model saved: gradient_boosting_model_final.pkl")
print("Data saved: hr_attrition_final_21features.csv")
